
mod isi1_explore {
    use super::*;
    use crate::kernel::scheduler::CpuId;
    use crate::kernel::task::{TaskStatus, WaitReason};
    use crate::runtime::SharedKernel;

    const SENDER: u64 = 7;

    fn queued_count(k: &SharedKernel, tid: u64) -> usize {
        k.with(|s| {
            let mut n = 0;
            for c in 0..2u8 {
                s.for_each_queued_on_for_test(CpuId(c), |_, t| {
                    if t.0 == tid {
                        n += 1
                    }
                });
            }
            n
        })
    }

    /// A REAL blocking send by a current task with a user ASID and a deadline.
    fn real_blocked_sender(k: &SharedKernel) -> (usize, CapId, u64) {
        k.with(|s| {
            s.set_timer_for_test(Timer::new(1));
            s.bring_up_cpu(CpuId(1)).expect("cpu1");
            s.register_task(SENDER).expect("task");
            s.with_tcbs_mut(|tcbs| {
                let t = tcbs.iter_mut().flatten().find(|t| t.tid.0 == SENDER).unwrap();
                t.asid = Some(crate::kernel::vm::Asid(5));
                t.cpu_affinity = Some(CpuId(0));
                Ok::<_, KernelError>(())
            })
            .unwrap();
            s.enqueue_current_cpu(SENDER).expect("enqueue");
            s.dispatch_next_task().expect("dispatch");
            assert_eq!(s.current_tid(), Some(SENDER));
            let (ep, send_cap, _recv) = s
                .create_endpoint_with_mode(1, EndpointMode::Synchronous)
                .expect("ep");
            let msg = Message::new(1, b"x").expect("msg");
            assert_eq!(
                s.ipc_send_with_deadline(send_cap, msg, 1),
                Err(KernelError::WouldBlock)
            );
            let d = s
                .with_tcbs(|tcbs| {
                    tcbs.iter().flatten().find(|t| t.tid.0 == SENDER).and_then(|t| t.ipc_timeout_deadline)
                })
                .unwrap();
            (ep, send_cap, d)
        })
    }

    #[test]
    fn explore_timeout_between_take_and_wake() {
        crate::kernel::boot::reset_ipc_timeout_scan_cursor(0);
        crate::kernel::boot::send_timeout_work_clear(0);
        crate::kernel::boot::send_timeout_work_clear(1);
        let k = SharedKernel::new(Bootstrap::init().expect("init"));
        let (ep, _cap, d) = real_blocked_sender(&k);
        std::println!("after block: status={:?} waiters={}", k.with(|s| s.task_status(SENDER)), k.with(|s| s.sender_waiter_count(ep)));
        // CPU 0, receiver phase 1: the rank-3 take.
        let (msg, target) = k.with(|s| s.ipc_recv_endpoint_take(ep)).expect("take");
        std::println!("take: msg={} target={:?}", msg.is_some(), target);
        // CPU 1: the timeout pipeline.
        let now = d + 1;
        k.collect_due_ipc_timeout_work(now, now, now, CpuId(1));
        k.drain_send_timeout_post_work(CpuId(1), now);
        std::println!("after timeout: status={:?} completion={:?} queued={}", k.with(|s| s.task_status(SENDER)), k.with(|s| s.pending_syscall_completion_result(SENDER)), queued_count(&k, SENDER));
        // CPU 0, receiver phase 2: the wake.
        let r = k.with(|s| s.apply_blocked_sender_wake(target));
        std::println!("after stale wake: r={:?} status={:?} completion={:?} queued={}", r, k.with(|s| s.task_status(SENDER)), k.with(|s| s.pending_syscall_completion_result(SENDER)), queued_count(&k, SENDER));
    }

    #[test]
    fn explore_publish_then_timeout_then_wake() {
        crate::kernel::boot::reset_ipc_timeout_scan_cursor(0);
        crate::kernel::boot::send_timeout_work_clear(0);
        crate::kernel::boot::send_timeout_work_clear(1);
        let k = SharedKernel::new(Bootstrap::init().expect("init"));
        let (ep, _cap, d) = real_blocked_sender(&k);
        let (_msg, target) = k.with(|s| s.ipc_recv_endpoint_take(ep)).expect("take");
        let target = target.expect("a sender");
        let p = k.with(|s| s.publish_blocking_send_completion(target, KernelState::SEND_COMPLETION_OK));
        std::println!("receiver published={} completion={:?}", p, k.with(|s| s.pending_syscall_completion_result(SENDER)));
        let now = d + 1;
        k.collect_due_ipc_timeout_work(now, now, now, CpuId(1));
        k.drain_send_timeout_post_work(CpuId(1), now);
        std::println!("after timeout: status={:?} completion={:?} queued={}", k.with(|s| s.task_status(SENDER)), k.with(|s| s.pending_syscall_completion_result(SENDER)), queued_count(&k, SENDER));
        let r = k.with(|s| s.wake_tid_to_runnable_for_test(crate::kernel::ipc::ThreadId(SENDER)));
        std::println!("after wake: r={:?} status={:?} queued={}", r, k.with(|s| s.task_status(SENDER)), queued_count(&k, SENDER));
    }

    #[test]
    fn explore_stale_wake_hits_next_cycle() {
        crate::kernel::boot::reset_ipc_timeout_scan_cursor(0);
        crate::kernel::boot::send_timeout_work_clear(0);
        crate::kernel::boot::send_timeout_work_clear(1);
        let k = SharedKernel::new(Bootstrap::init().expect("init"));
        let (ep, _cap, d) = real_blocked_sender(&k);
        let (_msg, target) = k.with(|s| s.ipc_recv_endpoint_take(ep)).expect("take");
        let now = d + 1;
        k.collect_due_ipc_timeout_work(now, now, now, CpuId(1));
        k.drain_send_timeout_post_work(CpuId(1), now);
        // The sender runs and blocks again on a second endpoint: a NEW cycle.
        let ep2 = k.with(|s| {
            while s.current_tid() != Some(SENDER) {
                s.dispatch_next_task().expect("dispatch");
            }
            let (ep2, cap2, _r) = s.create_endpoint_with_mode(1, EndpointMode::Synchronous).expect("ep2");
            let msg = Message::new(2, b"y").expect("msg");
            assert_eq!(s.ipc_send_with_deadline(cap2, msg, 100), Err(KernelError::WouldBlock));
            ep2
        });
        std::println!("new cycle: status={:?} gen={:?} waiters2={} deadline={:?}", k.with(|s| s.task_status(SENDER)), k.with(|s| s.with_tcbs(|t| t.iter().flatten().find(|t| t.tid.0 == SENDER).map(|t| t.blocked_send_generation))), k.with(|s| s.sender_waiter_count(ep2)), k.with(|s| s.with_tcbs(|t| t.iter().flatten().find(|t| t.tid.0 == SENDER).and_then(|t| t.ipc_timeout_deadline))));
        let r = k.with(|s| s.apply_blocked_sender_wake(target));
        std::println!("after stale wake: r={:?} status={:?} waiters2={} deadline={:?} completion={:?} queued={}", r, k.with(|s| s.task_status(SENDER)), k.with(|s| s.sender_waiter_count(ep2)), k.with(|s| s.with_tcbs(|t| t.iter().flatten().find(|t| t.tid.0 == SENDER).and_then(|t| t.ipc_timeout_deadline))), k.with(|s| s.pending_syscall_completion_result(SENDER)), queued_count(&k, SENDER));
    }
}
